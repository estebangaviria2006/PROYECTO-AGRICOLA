
var a = prompt("ingrese valor A: ")
var b = prompt("ingrese valor B: ")

if (a==b) {
    alert ("son iguales")
}

if (a>b) {
    alert ("A es MAYOR que B")
}
else{
       alert ("B es MAYOR que A")
}