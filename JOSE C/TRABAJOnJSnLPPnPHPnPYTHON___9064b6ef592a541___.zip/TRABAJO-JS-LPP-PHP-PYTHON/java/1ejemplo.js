Edad = prompt("ingrese su edad: ")
if (Edad>17) {
alert ("Usted tiene"+Edad+" años y es Mayor de edad")
}
else {
    alert ("ust es menor de edad")
    }