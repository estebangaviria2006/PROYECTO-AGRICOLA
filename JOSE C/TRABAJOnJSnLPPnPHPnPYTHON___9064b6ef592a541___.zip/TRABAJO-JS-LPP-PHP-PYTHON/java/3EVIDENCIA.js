var n1 = prompt("ingrese calificacion ")

if (n1 > 7) {
    console.log("APROBADO")
}
if (n1 < 7 ) {
    console.log("NO APROBO")
}