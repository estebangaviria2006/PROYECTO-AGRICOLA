<?php
$n1 = intval(readline(prompt:"primer numero \n"));

if($n1 > 7 ){
    echo "usted APROBO";
}

if($n1 < 7){
    echo "usted NO APROBO";
}
?>