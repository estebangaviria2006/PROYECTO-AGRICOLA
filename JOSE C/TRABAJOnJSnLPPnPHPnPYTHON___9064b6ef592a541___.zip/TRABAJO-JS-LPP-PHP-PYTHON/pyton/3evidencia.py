n1 = int(input("ingrese primer numero "))

if n1>7:
    print("APROBO")
if n1<7:
    print("NO APROBO")
