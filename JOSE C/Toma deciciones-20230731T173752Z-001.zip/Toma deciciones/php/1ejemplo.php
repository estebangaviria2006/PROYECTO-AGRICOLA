<?php
$edad = 1;
if ($edad >= 18) {
    echo " tienes ".$edad. "es Mayor de edad";
}
elseif ($edad){
    echo " Tienes ".$edad. "es Menor de edad";
}