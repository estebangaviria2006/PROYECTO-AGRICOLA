nota1 = int(input ("Ingrese primer nota "))
nota2 = int(input ("Ingrese segunda nota "))
nota3 = int(input ("Ingrese tercera nota "))

promedio = (nota1+nota2+nota3)/3


print ("su promedio es de ",promedio)
if promedio>70:
    print ("APROBO")
else:
    print ("NO APROBO")
    

