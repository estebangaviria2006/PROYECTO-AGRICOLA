hora = int(input("ingrese timepo que permanecio en el parqueadero "))

plata = hora * 1500

print("ust debe pagar por el servicio",plata)
