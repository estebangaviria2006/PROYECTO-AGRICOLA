n1 = float(input("ingrese primer numero "))
if n1>=11:
    print("tu nota sobrepasa la nota normal")
if n1==0:
    print("tu nota no existe")
if n1>=7 and n1<=10:
    print("felicitaciones aprobó")
if n1<7 and n1>=1:
    print("lo siento no aprobaste :(")
